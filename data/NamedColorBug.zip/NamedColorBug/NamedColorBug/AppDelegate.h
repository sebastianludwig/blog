//
//  AppDelegate.h
//  NamedColorBug
//
//  Created by Sebastian Ludwig on 14.07.18.
//  Copyright © 2018 Sebastian Ludwig. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

