//
//  ViewController.m
//  NamedColorBug
//
//  Created by Sebastian Ludwig on 14.07.18.
//  Copyright © 2018 Sebastian Ludwig. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UILabel *rgbColorLabel;
@property (weak, nonatomic) IBOutlet UILabel *sdkColorLabel;
@property (weak, nonatomic) IBOutlet UILabel *namedColorLabel;

@end

@implementation ViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.rgbColorLabel.backgroundColor = [UIColor greenColor];
    self.sdkColorLabel.backgroundColor = [UIColor greenColor];
    self.namedColorLabel.backgroundColor = [UIColor greenColor];
}

- (void)traitCollectionDidChange:(UITraitCollection *)previousTraitCollection
{
    [super traitCollectionDidChange:previousTraitCollection];
    // Bug: does NOT work
//    self.namedColorLabel.backgroundColor = [UIColor greenColor];
}

// The Soloution
//- (void)viewDidLayoutSubviews
//{
//    [super viewDidLayoutSubviews];
//    self.namedColorLabel.backgroundColor = [UIColor greenColor];
//}

@end
